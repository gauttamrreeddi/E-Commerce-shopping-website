<!doctype html>
<html>
<head>
<title>
Feedback
</title>
<style>
#login
{
margin-top: -20px;
margin-left:450px;
width: 450px;
text-align: center;
}
form fieldset input[type="text"], input[type="password"]
{
background-color: #e5e5e5; 
border: none;
border-radius: 30px;
color: #5a5656;
font-size: 14px;
height: 50px;
padding: 0px 10px;
width: 300px;
}
form fieldset input[type="textfield"]
{
	
background-color: #e5e5e5;
border: none;
border-radius: 30px;
color: #5a5656;
font-size: 14px;
height: 100px;
padding: 0px 10px;
width: 300px;
}
form fieldset input[type="button"]
{
background-color: Orange;
border: 2px;
border-radius: 100px;
color: #f4f4f4;
cursor: pointer;
height: 50px;
text-transform: uppercase;
width: 225px;
}
form fieldset a
{
color: #c0c0c0;
font-size: 13px;
}
h2
{
font-size: 2em;
color:Black;
}

h2, p
{
margin-bottom: 10px;
}

strong
{
font-weight: bold;
}

#main_para
{
color: #f4f4f4;
display: block;
font-size: 60px;
font-family: 'Open Sans', Arial, Helvetica, sans-serif;
height: 50px;
line-height: 20px;
margin: 170px 20px;
width: 750px;
float: left;
}

#navigationbar
{
margin-top: 24px;
margin-left:-800px;
float: left;
}
ul
{
list-style-type: none;
margin= 0;
padding= 0;
overflow: hidden;
background-color:Black;
}
li
{
float: left;
}
li a
{
display: block;
color: Black;
text-align: center;
padding: 10px 20px;
text-decoration: none;
}
li a:hover
{
background-color: Orange;
}
}
</style>
</head>
<body background="img/clipart18795.png">
<div id="main_para">
</br>
</div></center></ul>
</div></center></ul>
<div id="navigationbar">
<ul>
 <li><a href="home" style="color:white">Home</a></li>
<li><a href="mobile" style="color:white">Mobiles</a></li>
<li><a href="mens" style="color:white">Men </a></li>
<li><a href="women"  style="color:white">Women</a></li>
<li><a href="product"  style="color:white">Update Details</a></li>
<li><a href="contact" style="color:white">Customer Care</a></li>
<li><a href="login" style="color:white">LogOut</a></li>
</br></br>
</ul>
</br></br>
<div id="login">
<form onsubmit="return(validate())">
<fieldset>
<legend><h2><strong>Please Enter Your Card Details..!</strong></h2></legend>
<p><input id="1" type="text"  placeholder="Card Number" onmouseover="zoom_in(this)" onmouseout="zoom_out(this)"></p>
<p><input id="2" type="text"  placeholder="CVV" onmouseover="zoom_in(this)" onmouseout="zoom_out(this)"></p>
<a href="booked">
<input type="button" class="Book1" value="Proceed" ></button>
</a>
</fieldset>
</form>
</div>
<script>
function zoom_in(x)
{
x.style.height="59px"
x.style.width="350px"
}
function zoom_out(x)
{
x.style.height="50px"
x.style.width="300px"
}
</script>
</body>
</html>