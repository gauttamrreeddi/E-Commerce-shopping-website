@extends('navigation')

@section('text')

<h1 align="center">Welcome</h1>

<br/>



@endsection('text')