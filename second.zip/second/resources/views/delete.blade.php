<!DOCTYPE html>
<html>
<head>
</head>
<body>
<form method="POST" action="/regis/{{$emp->id}}">
	{{ csrf_field() }}


	{{ method_field('DELETE') }}

<legend><h2><strong>Delete!</strong></h2></legend>
name:
<input  type="text" name="name" value="{{ $emp2->name}} " ><br>
number:
<input  type="text" name="mobile" value="{{ $emp2->mobile}}"  ><br>
<input type="submit" value="delete">
</form>
</body>
</html>




