<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class registermodel extends Model
{
    public $table='registers';
}
