<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gowtham extends Model
{
    protected $table='registers';
}
