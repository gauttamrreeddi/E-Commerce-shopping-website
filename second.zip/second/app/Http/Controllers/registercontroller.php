<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class registercontroller extends Controller
{
    public function registermodels()
    {
    	return view('registers');
    } 


public function store()
    {
    	

    	
    } 
    
public function display()
  {
	$p=  \App\registermodel::All();
    	return view('register12', ['prod'=>$p ]);
  }
}
