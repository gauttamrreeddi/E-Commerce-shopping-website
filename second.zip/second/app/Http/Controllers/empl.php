<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class empl extends Controller
{
    public function emplo()
    {
    	return view('employeetable');
    } 

public function store()
    {
    	$emp = new \App\employe;
    	$emp -> name = request('name');
    	$emp -> email = request('email');
    	$emp -> salary = request('salary');
    	$emp -> designation = request('designation');
    	$emp -> save();
    } 
    
}
