<?php

namespace App\Http\Controllers;

use App\gowtham;
use Illuminate\Http\Request;

class gowthamcontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $emp=gowtham::all();
         return view('gow',compact('emp'));
       // return view('home');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('register');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $this->validate($request, [
            'name' => 'required',
            'mobile' => 'required',
            'email' => 'required',

        ]);
        
        
        $emp = new \App\registermodel;
        $emp -> name = request('name');
        $emp -> email = request('email');
        $emp -> password = request('password');
        $emp -> mobile = request('mobile');
        $emp -> gender = request('gender');
        $emp -> save();

        return redirect('/product');

       
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\gowtham  $gowtham
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       $emp= gowtham::find($id);

        //$emp=\App\gowtham::all();
        return view('updetails', compact('emp'));


       
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\gowtham  $gowtham
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $emp= gowtham::find($id);
        return view('edit',compact('emp'));
            //  return view('delete',compact('emp'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\gowtham  $gowtham
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
        $emp=gowtham::find($id);
        $emp->name=request('name');
        $emp->mobile=request('mobile');
        $emp->save();

        
        return redirect('/updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\gowtham  $gowtham
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $emp=gowtham::find($id);
        
         $emp->delete();
    }
}
