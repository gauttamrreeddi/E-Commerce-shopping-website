<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/registermigration', 'registercontroller@registermodels'); 
// Route::post('/home', 'registercontroller@storeee');

Route::resource('product','gowthamcontroller');
Route::resource('user','registercontroller');

Route::get('/welcome', function () {
    return view('welcome');
});



Route::get('/home', function () {
    return view('home');
});

Route::get('/show', function () {
    return view('show');
});

Route::get('/updetails', function () {
    return view('updetails');
});

Route::get('/mobile', function () {
    return view('mobile');
});

Route::get('/book', function () {
    return view('book');
});

Route::get('/women', function () {
    return view('women');
});

Route::get('/register12', function () {
    return view('register12');
});


Route::get('/contact', function () {
    return view('contact');
});

Route::get('/mens', function () {
    return view('mens');
});

Route::get('/login', function () {
    return view('login');
});

Route::get('/booked', function () {
    return view('booked');
});

Route::get('/updated', function () {
    return view('updated');
});



Route::get('/welcome', function () {
    return view('welcome');
});

Route::get('/', function () {
    return view('login');
});

Route::get('/navigation', function () {
    return view('navigation');
});


Route::get('/register', function () {
    return view('register');
});


Route::get('redirect',function() {
   return redirect()->route('testing');
});

// php artisan route:list
// Route::resource('employees','empcontroller')
// php artisan make:controller gowthamcontroller -r
// php artisan make:controller gowthamcontroller -r -m gowtham         -->creates model also

