<?php $__env->startSection('text'); ?>

<h1 align="center">Welcome</h1>

<br/>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>