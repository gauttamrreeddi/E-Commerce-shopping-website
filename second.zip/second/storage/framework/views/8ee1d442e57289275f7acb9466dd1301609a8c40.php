<!doctype html>
<html>
<head>
<title></title>
<style>
#navigationbar
{
margin-top: -19px;
margin-left:10px;
float: left;
}
ul
{
list-style-type: none;
margin= 0;
padding= 0;
overflow: hidden;
background-color:Black;
}
li
{
float: left;
}
li a
{
display: block;
color: White;
text-align: center;
padding: 10px 20px;
text-decoration: none;
}
li a:hover
{
background-color: Orange;
}

table,td
{
border:0px solid grey;
border-collapse:collapse;
text-align:center; 
color: SaddleBrown;
font-size: 20px;
}
th
{
border:0px solid grey;
border-collapse:collapse;
padding:55px;  
text-align:center; 
color:blue;
}
.th
{
color: black;
}
.plane
{
background-color: skyblue;
border: none;

color: #f4f4f4;
cursor: pointer;
height: 30px;
text-transform: uppercase;
width: 100px;
}

* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: none;
  padding: 6px 10px;
  margin-top: 8px;
  margin-left: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media  screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>

</head>
<body>
<div class="topnav">
  <a class="active" href="#home">Shop Now</a>
  
  <div class="search-container">
    <form action="/action_page.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
	  
    </form>
  </div>
</div>


<div id="navigationbar">
<ul>
 <li><a href="home" style="color:white">Home</a></li>
<li><a href="mobile" style="color:white">Mobiles</a></li>
<li><a href="mens" style="color:white">Men </a></li>
<li><a href="women"  style="color:white">Women</a></li>
<li><a href="product"  style="color:white">Update Details</a></li>
<li><a href="contact" style="color:white">Customer Care</a></li>
<li><a href="login" style="color:white">LogOut</a></li>
</ul>

<table>
<tr>
<th> 
<img class="mySlides" src="img/banner._CB453779223_.jpg" height="350px" width="1500px" >
</div>
</th>
</tr>
</table>
</div>
<legend><h2><strong>Deals of the Day</strong></h2></legend>

<script>
function btncolor(x)
{
x.style.backgroundColor="blue"
}

function btncolorr(x)
{
x.style.backgroundColor="skyblue"
}
</script>

<div id="field1">

<center>
<table >


<tr>
<td><img src="img/PL_HEX1.jpg" height="350" width="300"><p></br>Rs 999</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/winter_w.jpg" height="350" width="300"><p></br>Rs 3,999</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/Topstees.jpg" height="350" width="300"><p></br>Rs 8,999</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/sare.jpg" height="350" width="300"><p></br>Rs 1999</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/CB_W.jpg" height="350" width="300"><p></br>Rs 899</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>


</tr>
</table>

<h1><p><b>Top Brands</b></p><h1>
<table >
<tr>
<th colspan="4" style="background-color:white" class="th"></th>
</tr>

<tr>
<td><img src="img/veromodaBTmin60.jpg" height="450" width="400"><p>950</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/MISSCHASE.jpg" height="450" width="400"><p>899</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/BT04.jpg" height="450" width="400"><p>699</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/mns4060.jpg" height="450" width="400"><p>799</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>


</tr>
</table>


<table>
<tr>
<th> 
<img class="mySlides" src="img/Dec_DBA_Ingresses_Women_PC._CB458392804_.jpg" height="300px" width="1500px" >
</div>
</th>
</tr>
</table>

<h1><p><b>Jeans and Leggins</b></p><h1>
<table >
<tr>
<th colspan="4" style="background-color:white" class="th"></th>
</tr>

<tr>
<td><img src="img/31X3uHIvCBL._AC_UL390_SR300,390_FMwebp_QL65_.jpg" height="450" width="400"><p>599</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/31BQwfaBkBL._AC_UL390_SR300,390_FMwebp_QL65_.jpg" height="450" width="400"><p>733</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/31i2yIXblvL._AC_UL390_SR300,390_FMwebp_QL65_.jpg" height="450" width="400"><p>299</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>



</tr>
</table>

<table>
<tr>
<th> 
<img class="mySlides" src="img/1._CB483991571_.jpg" height="300px" width="1500px" >
</div>
</th>
</tr>
</table>

</body>
<ul>
</html>
