<!DOCTYPE html>
<html>
<head>
	</head>
	<body>
		<?php $__currentLoopData = $prod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($p->name); ?>

		
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</body>
	</html>