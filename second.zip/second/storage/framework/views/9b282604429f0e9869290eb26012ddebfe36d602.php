<!doctype html>
<html>
<head>
<title></title>
<style>
#navigationbar
{
margin-top: -19px;
margin-left:10px;
float: left;
}
ul
{
list-style-type: none;
margin= 0;
padding= 0;
overflow: hidden;
background-color:Black;
}
li
{
float: left;
}
li a
{
display: block;
color: White;
text-align: center;
padding: 10px 20px;
text-decoration: none;
}
li a:hover
{
background-color: Orange;
}

table,td
{
border:0px solid grey;
border-collapse:collapse;
text-align:center; 
color: SaddleBrown;
font-size: 20px;
}
th
{
border:0px solid grey;
border-collapse:collapse;
padding:55px;  
text-align:center; 
color:blue;
}
.th
{
color: black;
}
.plane
{
background-color: skyblue;
border: none;

color: #f4f4f4;
cursor: pointer;
height: 30px;
text-transform: uppercase;
width: 100px;
}

* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: none;
  padding: 6px 10px;
  margin-top: 8px;
  margin-left: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media  screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>

</head>
<body>
<div class="topnav">
  <a class="active" href="#home">Shop Now</a>
  
  <div class="search-container">
    <form action="/action_page.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
	  
    </form>
  </div>
</div>


<div id="navigationbar">
<ul>
 <li><a href="home" style="color:white">Home</a></li>
<li><a href="mobile" style="color:white">Mobiles</a></li>
<li><a href="mens" style="color:white">Men </a></li>
<li><a href="women"  style="color:white">Women</a></li>
<li><a href="product"  style="color:white">Update Details</a></li>
<li><a href="contact" style="color:white">Customer Care</a></li>
<li><a href="login" style="color:white">LogOut</a></li>
</ul>

<table>
<tr>
<th> 
<img class="mySlides" src="img/D9482266_IN_WL_FabPhoneFest_Teaser_LP_1500x300._CB467672421_.jpg" height="300px" width="1500px" >
</div>
</th>
</tr>
</table>
</div>


<script>
function btncolor(x)
{
x.style.backgroundColor="blue"
}

function btncolorr(x)
{
x.style.backgroundColor="skyblue"
}
</script>


<div id="field1">

<center>
<h1><p><b>Samsung Mobiles</b></p><h1>
<table >
<tr>
<th colspan="4" style="background-color:white" class="th"></th>
</tr>

<tr>
<td><img src="img/51EfDWKl24L.AC_AA200.jpg" height="350" width="400"><p>Samsung Galaxy M10</br>Rs 9,999</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/713kEBUCw-L.AC_AA200.jpg" height="350" width="400"><p>Samsung Galaxy M20</br>Rs 13,999</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/81xl7IHBw-L.AA200_.jpg" height="350" width="400"><p>Samsung Galaxy M30</br>Rs 18,999</br>
<a href="book">
  <input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/61AWYGbBYLL.AA200_.jpg" height="350" width="400"><p>Samsung Galaxy A50</br>Rs 19,999</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>


</tr>
</table>
<table >
<tr>
<th colspan="4" style="background-color:white" class="th"></th>
</tr>

<tr>
<td><img src="img/31inxN86KRL._AC_US240_QL65_.jpg" height="350" width="400"><p>Samsung Galaxy S10</br>Rs 9,999</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/41hoYsGQJWL._AC_US240_FMwebp_QL65_.jpg" height="350" width="400"><p>Samsung Galaxy J8</br>Rs 13,999</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/419mck7Tw1L._AC_US240_FMwebp_QL65_ (1).jpg" height="350" width="400"><p>Samsung Galaxy C9 Pro</br>Rs 18,999</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/41UpXazDTUL._AC_US240_FMwebp_QL65_.jpg" height="350" width="400"><p>Samsung Galaxy Note 9</br>Rs 19,999</br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>


</tr>
</table>
<table >
<tr>
<th colspan="4" style="background-color:white" class="th"></th>
</tr>

<tr>
<td><img src="img/D9439154_Honor_March_Axis_CC_Tile_670x700._CB469575017_.jpg" height="450" width="400"><p></br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/D9463253-_IN_WL_Mi_Mob_Heroes_Cat_Page_Creatives_ICICI_Redmi_6A_670x700._CB469575223_.jpg" height="450" width="400"><p></br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/D9398316_BAU_OPPO_F11ProSale_HDFC_670x700._CB1198675309_.jpg" height="450" width="400"><p></br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>
<td><img src="img/D9462999_Huawei_Y9_Holi_ICICI_cg_670x700._CB469574903_.jpg" height="450" width="400"><p> </br>
<a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</p></td>


</tr>
</table>


<table>
<tr>
<th> 
<img class="mySlides" src="img/D9439628_ICICI_EMI_Offers_19th_March_24th_March_PC_stripe_1500x200._CB469576176_.jpg" height="300px" width="1500px" >
</div>
</th>
</tr>
</table>



</body>
<ul>
</html>
