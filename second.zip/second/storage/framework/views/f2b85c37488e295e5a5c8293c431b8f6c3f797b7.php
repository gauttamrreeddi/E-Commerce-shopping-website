<?php $__env->startSection('text'); ?>

<title>
Welcome: Online Reservation
</title>
<style>

#login
{
margin-top: -30px;
margin-left:950px;
width: 350px;
text-align: center;
}

#para
{
margin-top:-30px;
margin-left: 30px;
width: 750px;
height: 500px;
float: left;
}



.welcome
{
background-color:  #d2691e;
border: none;
border-radius: 50px;
color: #f4f4f4;
cursor: pointer;
height: 50px;
text-transform: uppercase;
width: 400px;
margin-top:35px;
margin:left:50px;
margin-right:200px;
float: right;
}

form fieldset input[type="text"], input[type="password"]
{
background-color: #e5e5e5;
border: none;
border-radius: 3px;
border-radius: 30px;
color: #5a5656;
font-size: 14px;
height: 50px;
outline: none;
padding: 0px 10px;
width: 220px;
}

form fieldset input[type="submit"]
{
background-color: #d2691e;
border: none;
border-radius: 3px;
border-radius: 100px;
color: #f4f4f4;
cursor: pointer;
height: 30px;
text-transform: uppercase;
width: 225px;
}

form fieldset a
{
color: #c0c0c0;
font-size: 13px;
}

h2
{
font-size: 2em;
color: SaddleBrown;
}

h2, p
{
margin-bottom: 10px;
}

strong
{
font-weight: bold;
}

.birth
{
color: black;
margin-bottom:10px;
font-size:1em;
}

.dob
{
background-color: #e5e5e5;
border: none;
border-radius: 3px;
border-radius: 10px;
color: #5a5656;
font-size: 14px;
height: 50px;
outline: none;
padding: 0px 10px;
width: 76px;
}

.gender
{
font-size: 10px;
outline: none;
width: 30px;
}

#main_para
{
color: #f4f4f4;
display: block;
font-size: 30px;
height: 50px;
line-height: 15px;
margin: 190px 30px;
width: 750px;
float: left;
}

.register1
{
background-color:  #d2691e;
border: none;
border-radius: 50px;
margin-top: 15px;
margin-left:1010px;
color: #f4f4f4;
cursor: pointer;
height: 30px;
text-transform: uppercase;
width: 225px;
}

</style>

<div id="login">
<form onsubmit="return(validate())">
<fieldset>
<legend><h2><strong>Register now!</strong></h2></legend>
<p><input id="1" type="text"  placeholder="How your mom calls you?" onmouseover="zoom_in(this)" onmouseout="zoom_out(this)"></p>
<p><input id="2" type="text"  placeholder="Surname" onmouseover="zoom_in(this)" onmouseout="zoom_out(this)"></p>
<p><input id="3" type="text" placeholder="Enter your Email ID" onmouseover="zoom_in(this)" onmouseout="zoom_out(this)"></p>
<p><input id="4" type="password"  placeholder="Enter your Password here" onmouseover="zoom_in(this)" onmouseout="zoom_out(this)"></p>
<p><input id="5" type="text" placeholder="Mobile number" onmouseover="zoom_in(this)" onmouseout="zoom_out(this)"></p>

<p class="birth"><strong>Birthday</strong></p>
<select id="6" class="dob" onmouseover="zoom_in_dob(this)" onmouseout="zoom_out_dob(this)">
<option value="-1"> day </option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select>

<select id="7" class="dob" onmouseover="zoom_in_dob(this)" onmouseout="zoom_out_dob(this)">
<option value="-1"> month </option>
<option value="jan">Jan</option>
<option value="Feb">Feb</option>
<option value="Mar">Mar</option>
<option value="Apr">Apr</option>
<option value="May">May</option>
<option value="Jun">Jun</option>
<option value="Jul">Jul</option>
<option value="Aug">Aug</option>
<option value="Spt">Spt</option>
<option value="Oct">Oct</option>
<option value="Nov">Nov</option>
<option value="Dec">Dec</option>
</select>

<select id="8" class="dob" onmouseover="zoom_in_dob(this)" onmouseout="zoom_out_dob(this)">
<option value="-1"> year </option>
<option value="1">2016</option>
<option value="2">2015</option>
<option value="3">2014</option>
<option value="4">2013</option>
<option value="5">2012</option>
<option value="6">2011</option>
<option value="7">2010</option>
<option value="8">2009</option>
<option value="9">2008</option>
<option value="10">2007</option>
<option value="11">2006</option>
<option value="12">2005</option>
<option value="13">2004</option>
<option value="14">2003</option>
<option value="15">2002</option>
<option value="16">2001</option>
<option value="17">2000</option>
<option value="18">1999</option>
<option value="19">1998</option>
<option value="20">1997</option>
<option value="21">1996</option>
<option value="22">1995</option>
<option value="23">1994</option>
<option value="24">1993</option>
<option value="25">1992</option>
<option value="26">1991</option>
<option value="27">1990</option>
<option value="28">1989</option>
<option value="29">1988</option>
<option value="30">1987</option>
<option value="31">1986</option>
<option value="31">1985</option>
<option value="31">1984</option>
<option value="31">1983</option>
<option value="31">1982</option>
<option value="31">1981</option>
<option value="31">1980</option>
<option value="31">1979</option>
<option value="31">1978</option>
<option value="31">1977</option>
<option value="31">1976</option>
<option value="31">1975</option>
<option value="31">1974</option>
<option value="31">1973</option>
<option value="31">1972</option>
<option value="31">1971</option>
<option value="31">1970</option>
<option value="31">1969</option>
<option value="31">1968</option>
<option value="31">1967</option>
<option value="31">1966</option>
<option value="31">1965</option>
</select><br><br>
<p><input id="9" type="radio" class="gender" value="male" name="name" ><b><strong>Male</b></strong>
<input  type="radio" class="gender" value="female" name="name" ></b><strong>Female</strong></b></p>
<p><a href="main page.html"><input type="submit"  value="CREATE YOUR ACCOUNT" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></a></p>
</form>

</fieldset>
</div>
<a href="/welcome">
<input type="button" class="register1" value="Go Back To Welcome Page" >
</a>


<script>
function validate()
{
if(document.getElementById("1").value=="")
{
alert("Please enter your name");
document.getElementById("1").focus();
return false;
}

if(document.getElementById("2").value=="")
{
alert("Please enter your surname");
document.getElementById("2").focus();
return false;
}

if(document.getElementById("3").value=="")
{
alert("Please enter your Email Id");
document.getElementById("3").focus();
return false;
}

if(document.getElementById("4").value=="")
{
alert("Please enter your password");
document.getElementById("4").focus();
return false;
}

if(document.getElementById("5").value=="")
{
alert("Please enter your mobile number");
document.getElementById("5").focus();
return false;
}

if(document.getElementById("6").value=="-1")
{
alert("Please select the day");
document.getElementById("6").focus();
return false;
}

if(document.getElementById("7").value=="-1")
{
alert("Please select the month");
document.getElementById("7").focus();
return false;
}
if(document.getElementById("8").value=="-1")
{
alert("Please select the year");
document.getElementById("8").focus();
return false;
}
if(document.getElementById("9").value=="name")
{
alert("Please select the Gender");
document.getElementById("9").focus();
return false;
}
alert("Account Is created Please Press Go Back Option to Login");
return true;
login()
}
function zoom_in(x)
{
x.style.height="59px"
x.style.width="270px"
}

function zoom_out(x)
{
x.style.height="50px"
x.style.width="220px"
}

function zoom_in_dob(x)
{
x.style.height="59px"
x.style.width="126px"
}

function zoom_out_dob(x)
{
x.style.height="50px"
x.style.width="76px"
}

function btncolor(x)
{
x.style.backgroundColor="SaddleBrown"
}

function btncolorr(x)
{
x.style.backgroundColor="#d2691e"
}

function alert1()
{
alert("You will get better offers if you get register with us...")
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>