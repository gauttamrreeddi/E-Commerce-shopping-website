 


<?php $__env->startSection('text'); ?>
<title>
Airlines Reservation
</title>
<style>

#login
{
margin-top: 20px;
margin-left:450px;
width: 400px;
text-align: center;
}

#para
{
margin-top:-30px;
margin-left: 30px;
width: 750px;
height: 500px;
float: left;
}

.btn-round
{
background-color: #5a5656;
border-radius: 50%;
border-radius: 50%;
color: #f4f4f4;
display: block;
font-size: 12px;
height: 50px;
line-height: 50px;
margin: 30px 129px;
text-align: center;
text-transform: uppercase;
width: 50px;
}

.register1
{
background-color:  #d2691e;
border: none;
border-radius: 100px;
color: #f4f4f4;
cursor: pointer;
height: 50px;
text-transform: uppercase;
width: 225px;
}

.login2
{
background-color:  #d2691e;
border: none;
border-radius: 100px;
color: #f4f4f4;
cursor: pointer;
height: 50px;
text-transform: uppercase;
width: 225px;
}

.welcome
{
background-color:  #d2691e;
border: none;
border-radius: 50px;
color: #f4f4f4;
cursor: pointer;
height: 50px;
text-transform: uppercase;
width: 400px;
margin-top:35px;
margin:left:50px;
margin-right:200px;
float: right;
}

form fieldset input[type="text"], input[type="password"]
{
background-color: #e5e5e5;
border: none;
border-radius: 3px;
border-radius: 30px;
color: #5a5656;
font-size: 15px;
height: 50px;
outline: none;
padding: 0px 10px;
width: 220px;
}


form fieldset a
{
color: black;
font-size: 15px;
}

h2
{
font-size: 2em;
color:SaddleBrown;
}

h2, p
{
margin-bottom: 10px;
}

strong
{
font-weight: bold;
}

#main_para
{
color: #f4f4f4;
display: block;
font-size: 30px;
height: 50px;
line-height: 15px;
margin: 190px 30px;
width: 750px;
float: left;
}


</style>

<div id="login">

	
<form method="POST" action="/product/<?php echo e($emp->id); ?>">
	<?php echo e(csrf_field()); ?>



	<?php echo e(method_field('PATCH')); ?>

	<fieldset>

<legend><h2><strong>Update!</strong></h2></legend>
Name:
<p><input id="1" type="text" name="name" value="<?php echo e($emp->name); ?> " onmouseover="zoom_in(this)" onmouseout="zoom_out(this)"></p>
Mobile Number:
<p><input id="2" type="text" name="mobile" value="<?php echo e($emp->mobile); ?>" onmouseover="zoom_in(this)" onmouseout="zoom_out(this)"></p>

<input type="submit" class="register1" value="UPDATE" onmouseover="btncolor(this)" onmouseout="btncolorr(this)">
</a></p>

</fieldset>
</form>

</div>
<script>


function zoom_in(x)
{
x.style.height="59px"
x.style.width="270px"
}

function zoom_out(x)
{
x.style.height="50px"
x.style.width="220px"
}

function zoom_in_dob(x)
{
x.style.height="59px"
x.style.width="126px"
}

function zoom_out_dob(x)
{
x.style.height="50px"
x.style.width="76px"
}

function btncolor(x)
{
x.style.backgroundColor="SaddleBrown"
}

function btncolorr(x)
{
x.style.backgroundColor="#d2691e"
}


</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>