<html>
   <body>
      <h1>Example of Redirecting to Named Routes</h1>
   </body>
</html>