<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<h1><?php echo e($emp->name); ?></h1>
	<h1><?php echo e($emp->salary); ?></h1>
<a href="/editt/<?php echo e($emp->id); ?>/edit">
	edit
</a>
</body>
</html>

