<?php $__env->startSection('text'); ?>

<title>
Welcome: Online Reservation
</title>
<style>

#login
{
margin-top: -30px;
margin-left:950px;
width: 350px;
text-align: center;
}

#para
{
margin-top:-30px;
margin-left: 30px;
width: 750px;
height: 500px;
float: left;
}



.welcome
{
background-color:  #d2691e;
border: none;
border-radius: 50px;
color: #f4f4f4;
cursor: pointer;
height: 50px;
text-transform: uppercase;
width: 400px;
margin-top:35px;
margin:left:50px;
margin-right:200px;
float: right;
}

form fieldset input[type="text"], input[type="password"]
{
background-color: #e5e5e5;
border: none;
border-radius: 3px;
border-radius: 30px;
color: #5a5656;
font-size: 14px;
height: 50px;
outline: none;
padding: 0px 10px;
width: 220px;
}

form fieldset input[type="submit"]
{
background-color: #d2691e;
border: none;
border-radius: 3px;
border-radius: 100px;
color: #f4f4f4;
cursor: pointer;
height: 30px;
text-transform: uppercase;
width: 225px;
}

form fieldset a
{
color: #c0c0c0;
font-size: 13px;
}

h2
{
font-size: 2em;
color: SaddleBrown;
}

h2, p
{
margin-bottom: 10px;
}

strong
{
font-weight: bold;
}

.birth
{
color: black;
margin-bottom:10px;
font-size:1em;
}

.dob
{
background-color: #e5e5e5;
border: none;
border-radius: 3px;
border-radius: 10px;
color: #5a5656;
font-size: 14px;
height: 50px;
outline: none;
padding: 0px 10px;
width: 76px;
}

.gender
{
font-size: 10px;
outline: none;
width: 30px;
}

#main_para
{
color: #f4f4f4;
display: block;
font-size: 30px;
height: 50px;
line-height: 15px;
margin: 190px 30px;
width: 750px;
float: left;
}

.register1
{
background-color:  #d2691e;
border: none;
border-radius: 50px;
margin-top: 15px;
margin-left:1010px;
color: #f4f4f4;
cursor: pointer;
height: 30px;
text-transform: uppercase;
width: 225px;
}

</style>

<div id="login">
<form method = "POST" action = "/contact" >
	<?php echo e(csrf_field()); ?>

<fieldset>
<p><input id="1" type="text"  placeholder="Name" name ="name" onmouseover="zoom_in(this)" onmouseout="zoom_out(this)"></p>
<p><input id="2" type="text"  placeholder="email" name ="email"  onmouseover="zoom_in(this)" onmouseout="zoom_out(this)"></p>
<p><input id="3" type="text" placeholder="salary" name ="salary" onmouseover="zoom_in(this)" onmouseout="zoom_out(this)"></p>
<p><input id="4" type="password"  placeholder="designation" name ="designation"  onmouseover="zoom_in(this)" onmouseout="zoom_out(this)"></p>

<p><input type="submit"  value="Add" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></p>
</form>

</fieldset>
</div>



<script>
function validate()
{
if(document.getElementById("1").value=="")
{
alert("Please enter your name");
document.getElementById("1").focus();
return false;
}

if(document.getElementById("2").value=="")
{
alert("Please enter your surname");
document.getElementById("2").focus();
return false;
}

if(document.getElementById("3").value=="")
{
alert("Please enter your Email Id");
document.getElementById("3").focus();
return false;
}

if(document.getElementById("4").value=="")
{
alert("Please enter your password");
document.getElementById("4").focus();
return false;
}

if(document.getElementById("5").value=="")
{
alert("Please enter your mobile number");
document.getElementById("5").focus();
return false;
}

if(document.getElementById("6").value=="-1")
{
alert("Please select the day");
document.getElementById("6").focus();
return false;
}

if(document.getElementById("7").value=="-1")
{
alert("Please select the month");
document.getElementById("7").focus();
return false;
}
if(document.getElementById("8").value=="-1")
{
alert("Please select the year");
document.getElementById("8").focus();
return false;
}
if(document.getElementById("9").value=="name")
{
alert("Please select the Gender");
document.getElementById("9").focus();
return false;
}
alert("Account Is created Please Press Go Back Option to Login");
return true;
login()
}
function zoom_in(x)
{
x.style.height="59px"
x.style.width="270px"
}

function zoom_out(x)
{
x.style.height="50px"
x.style.width="220px"
}

function zoom_in_dob(x)
{
x.style.height="59px"
x.style.width="126px"
}

function zoom_out_dob(x)
{
x.style.height="50px"
x.style.width="76px"
}

function btncolor(x)
{
x.style.backgroundColor="SaddleBrown"
}

function btncolorr(x)
{
x.style.backgroundColor="#d2691e"
}

function alert1()
{
alert("You will get better offers if you get register with us...")
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>