<!doctype html>
<html>
<head>
<title></title>
<style>
#navigationbar
{
margin-top: -19px;
margin-left:10px;
float: left;
}
ul
{
list-style-type: none;
margin= 0;
padding= 0;
overflow: hidden;
background-color:Black;
}
li
{
float: left;
}
li a
{
display: block;
color: White;
text-align: center;
padding: 10px 20px;
text-decoration: none;
}
li a:hover
{
background-color: Orange;
}

table,td
{
border:0px solid grey;
border-collapse:collapse;
text-align:center; 
color: SaddleBrown;
font-size: 20px;
}
th
{
border:0px solid grey;
border-collapse:collapse;
padding:55px;  
text-align:center; 
color:blue;
}
.th
{
color: black;
}
.plane
{
background-color: skyblue;
border: none;

color: #f4f4f4;
cursor: pointer;
height: 30px;
text-transform: uppercase;
width: 100px;
}

* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: none;
  padding: 6px 10px;
  margin-top: 8px;
  margin-left: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media  screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>

</head>
<body>
<div class="topnav">
  <a class="active" href="#home">Shop Now</a>
  
  <div class="search-container">
    <form action="/action_page.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
	  
    </form>
  </div>
</div>


<div id="navigationbar">
<ul>
  <li><a href="home" style="color:white">Home</a></li>
<li><a href="mobile" style="color:white">Mobiles</a></li>
<li><a href="mens" style="color:white">Men </a></li>
<li><a href="women"  style="color:white">Women</a></li>
<li><a href="product"  style="color:white">Update Details</a></li>
<li><a href="contact" style="color:white">Customer Care</a></li>
<li><a href="login" style="color:white">LogOut</a></li>

</ul>

<table>
<tr>
<th> 

<img class="mySlides" src="img/EMI-fest_DesktopHero_ICICI_1500x600_1._CB468095215_ (1).jpg" height="300px" width="1500px" >
<img class="mySlides" src="img/V105006557_HETV_IPLTVs_Livestore_Ingress_graphics_1500x300._CB469096639_.jpg" height="300px" width="1500px" >
<img class="mySlides" src="img/V104274033_HETV_MiTV_750x300._CB468911037_.jpg" height="300px" width="1500px">
<img class="mySlides" src="img/1082676_TV_premium_tv_PC_banner._CB490277148_.jpg" height="300px" width="1500px" >
<img class="mySlides" src="img/D9572384_IN_WL_Mi_A2_BAU_ICICI_DesktopTallHero_1500x600._CB468092719_.jpg" height="300px" width="1500px" >
<img class="mySlides" src="img/EMI-fest_DesktopHero_ICICI_1500x600_1._CB468095215_ (1).jpg" height="300px" width="1500px" >
</div>
</th>
</tr>
</table>
</div>
<legend><h2><strong>Deals of the Day</strong></h2></legend>
</script>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<a href="">
<input type="button" class="plane" value="View All" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a>
</script>
<script>
function btncolor(x)
{
x.style.backgroundColor="blue"
}

function btncolorr(x)
{
x.style.backgroundColor="skyblue"
}
</script>

<div id="field1">

<center>
  <h1><p><b>Maximum Discount On All Products</b></p><h1><h5>* T & C Apply<h5>
<table >
<tr>
<th colspan="5" style="background-color:white" class="th"></th>
</tr>

<tr>
<td><img src="img/71TDRCLIDML._AC_SY200_.jpg" height="350" width="300"><a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a></td>
<td><img src="img/Laptops._CB454409461_.jpg" height="350" width="300"><a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a></td>
<td><img src="img/260_Lifestyle._CB467669278_SY260_.jpg" height="350" width="300"><a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a></td>
<td><img src="img/NC_EMI_Desktop_card_260x260._CB467829331_SY260_.jpg" height="350" width="300"><a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a></p></td>
<td><img src="img/ICICI_Desktop_card_260x260._CB467829407_SY260_.jpg" height="350" width="300"><a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a></td>

</tr>
</table>

<table>
<tr>
<th> 

<img class="Slides" src="img/slide1.jpg" height="300px" width="1500px" >
<img class="Slides" src="img/slide2.jpg" height="300px" width="1500px" >
<img class="Slides" src="img/slide3.jpg" height="300px" width="1500px">
</div>
</th>
</tr>
</table>

<table >
<tr>
<th colspan="5" style="background-color:white" class="th"></th>
</tr>

<tr>
<td><img src="img/11O._CB453990151_SY260_.jpg" height="350" width="300"><a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a></td>
<td><img src="img/SA260X260._CB453940874_SY260_ (1).jpg" height="350" width="300"><a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a></td>
<td><img src="img/WallClocks2._CB453938852_SY260_.jpg" height="350" width="300"><a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a></td>
<td><img src="img/CE-elec_520x520._CB453990316_SY260_.jpg" height="350" width="300"><a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a></td>
<td><img src="img/handk1._CB453963672_SY260_.jpg" height="350" width="300"><a href="book">
<input type="button" class="plane" value="Buy Now" onmouseover="btncolor(this)" onmouseout="btncolorr(this)"></button>
</a></td>

</tr>

</form></td>
</table>

<script>
var myIndex = 0;
changepics();
changepic();
function changepics() 
{
var i;
var x = document.getElementsByClassName("mySlides");
for(i = 0; i < x.length; i++)
{
x[i].style.display = "none";
}
myIndex++;
if(myIndex >x.length )
{
myIndex=1
}
x[myIndex-1].style.display = "block";
setTimeout(changepics, 2000); 
}
function changepic() 
{
var i;
var x = document.getElementsByClassName("Slides");
for(i = 0; i < x.length; i++)
{
x[i].style.display = "none";
}
myIndex++;
if(myIndex >x.length )
{
myIndex=1
}
x[myIndex-1].style.display = "block";
setTimeout(changepic, 2000); 
}

</script>

</body>
<ul>
</html>
