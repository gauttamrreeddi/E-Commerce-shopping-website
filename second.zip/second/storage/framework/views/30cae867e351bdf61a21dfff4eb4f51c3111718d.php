<?php $__env->startSection('text'); ?>
<head>
	<title></title>
	<style>

#login
{
margin-top: 20px;
margin-left:450px;
width: 400px;
text-align: center;
}

#para
{
margin-top:-30px;
margin-left: 30px;
width: 750px;
height: 500px;
float: left;
}

.btn-round
{
background-color: #5a5656;
border-radius: 50%;
border-radius: 50%;
color: #f4f4f4;
display: block;
font-size: 12px;
height: 50px;
line-height: 50px;
margin: 30px 129px;
text-align: center;
text-transform: uppercase;
width: 50px;
}

.register1
{
background-color:  #d2691e;
border: none;
border-radius: 100px;
color: #f4f4f4;
cursor: pointer;
height: 50px;
text-transform: uppercase;
width: 225px;
}

.login2
{
background-color:  #d2691e;
border: none;
border-radius: 100px;
color: #f4f4f4;
cursor: pointer;
height: 50px;
text-transform: uppercase;
width: 225px;
}

.welcome
{
background-color:  #d2691e;
border: none;
border-radius: 50px;
color: #f4f4f4;
cursor: pointer;
height: 50px;
text-transform: uppercase;
width: 400px;
margin-top:35px;
margin:left:50px;
margin-right:200px;
float: right;
}

form fieldset input[type="text"], input[type="password"]
{
background-color: #e5e5e5;
border: none;
border-radius: 3px;
border-radius: 30px;
color: #5a5656;
font-size: 15px;
height: 50px;
outline: none;
padding: 0px 10px;
width: 220px;
}


form fieldset a
{
color: black;
font-size: 15px;
}

h2
{
font-size: 2em;
color:SaddleBrown;
}

h2, p
{
margin-bottom: 10px;
}

strong
{
font-weight: bold;
}

#main_para
{
color: #f4f4f4;
display: block;
font-size: 30px;
height: 50px;
line-height: 15px;
margin: 190px 30px;
width: 750px;
float: left;
}


</style>


	<div >
		<fieldset id="login">
			<legend><h2><strong>Details..!</strong></h2></legend>
    
    <b><h1><?php echo e($emp->name); ?></h1></b>
    <b><h2><li><?php echo e($emp->mobile); ?></li></h2></b>

  

<b><h2><li><a href="/product/<?php echo e($emp->id); ?>/edit"> EDIT</a></li></h2></b>
</fieldset>
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>