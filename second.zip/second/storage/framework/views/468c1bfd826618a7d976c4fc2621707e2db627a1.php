<?php $__env->startSection('text'); ?>

<style>
#field1
{
background-color:lavender;
margin-top: 70px;
margin-left:60px;
width: 1200px;
text-align: center;
}
table,td
{
border:0px solid grey;
border-collapse:collapse;
text-align:center; 
color: SaddleBrown;
font-size: 20px;
}
th
{
border:0px solid grey;
border-collapse:collapse;
padding:15px;  
text-align:center; 
color:blue;
}
.th
{
color: black;
}
.Persons
{
background-color: lightblue;
border: none;
border-radius: 3px;
border-radius: 10px;
color: #5a5656;

font-size: 14px;
height: 50px;
outline: none;
padding: 0px 10px;
width: 50px;
}
.Book1
{
background-color:skyblue;
border: none;
color: blue;
border-radius: 30px;
cursor: pointer;
height: 50px;
text-transform: uppercase;
width: 225px;
}

.total_price
{
background-color: lightblue;
border: none;
border-radius: 3px;
border-radius: 30px;
color: #5a5656;
font-family: 'Open Sans', Arial, Helvetica, sans-serif;
font-size: 20px;
height: 50px;
outline: none;
padding: 0px 10px;
width: 150px;
}

</style>


<div id="field1">
<fieldset>
<center>
<table align="center">
<tr>
<th colspan="7" style="background-color:orange" class="th">PRODUCTS</th>
</tr>
<tr>
<th>Image</th>
<th>Movie Name</th>
<th>Price</th>
<th>Qantity</th>
<th>Total price</th>
</tr>
<tr>
<td><img src="img/wp1966751-kung-fu-panda-wallpapers.jpg" height="150" width="150"></td>
<td>Kung Fu Panda 1</td>
<td>Rs:3000</td>
<td><form><select id="1" class="Persons" onchange="dis1()">
<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option> </select></form></td>
<td><form><input type="text" id="11" class="total_price" ></form></td>
<td><a href="name.php">
<input type="button" class="Book1" value="BOOK" ></button>
</a></td>
</select></form></td>
</tr>
<tr>
<td><img src="img/wp1966772-kung-fu-panda-wallpapers.jpg" height="150" width="150"></td>
<td>Kung Fu Panda 2</td>
<td>Rs:3100</td>
<td><form><select id="2" class="Persons" onchange="dis2()">
<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option></select></form></td>
<td><form><input type="text" id="22" class="total_price" ></form></td>
<td><a href="name.php">
<input type="button" class="Book1" value="BOOK" ></button>
</a></td>
</tr>
<tr>
<td><img src="img/kung-fu-panda-3_596.jpeg" height="150" width="150"></td>
<td>Kung Fu Panda 3</td>
<td>Rs:2160</td>
<td><form><select id="3" class="Persons" onchange="dis3()">
<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option></select></form></td>
<td><form><input type="text" id="33" class="total_price" ></form></td>
<td><a href="name.php">
<input type="button" class="Book1" value="BOOK" ></button>
</a></td>
</tr>
<tr>
<td><img src="img/thor_in_avengers_infinity_war_chris_hemsworth_4k_8k.jpg" height="150" width="150"></td>
<td>Thor </td>
<td>Rs:3120</td>
<td><form><select id="4" class="Persons" onchange="dis4()">
<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option></select></form></td>
<td><form><input type="text" id="44" class="total_price" ></form></td>
<td><a href="name.php">
<input type="button" class="Book1" value="BOOK" ></button>
</a></td>
</tr>
<tr>
<td><img src="img/deadpool-7.jpg" height="150" width="150"></td>
<td>Deadpool</td>
<td>Rs:4000</td>
<td><form><select id="5" class="Persons" onchange="dis5()">
<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option></select></form></td>
<td><form><input type="text" id="55" class="total_price" ></form></td>
<td><a href="name.php">
<input type="button" class="Book1" value="BOOK" ></button>
</a></td>
</tr>

</table>
<br><br>
</center>
</fieldset>
</div>
<script>
function validate()
{
href="home.html" 
}
function dis1()
{
var a=document.getElementById("1").value;
b=document.getElementById("11");
b.value=a*3000;
}
function dis2()
{
var a=document.getElementById("2").value;
b=document.getElementById("22");
b.value=a*3100;
}
function dis3()
{
var a=document.getElementById("3").value;
b=document.getElementById("33");
b.value=a*2160;
}
function dis4()
{
var a=document.getElementById("4").value;
b=document.getElementById("44");
b.value=a*3120;
}
function dis5()
{
var a=document.getElementById("5").value;
b=document.getElementById("55");
b.value=a*4000;
}
function dis6()
{
var a=document.getElementById("6").value;
b=document.getElementById("66");
b.value=a*4050;
}
function dis7()
{
var a=document.getElementById("7").value;
b=document.getElementById("77");
b.value=a*3500;
}
function dis8()
{
var a=document.getElementById("8").value;
b=document.getElementById("88");
b.value=a*4500;
}
function dis9()
{
var a=document.getElementById("9").value;
b=document.getElementById("99");
b.value=a*2000;
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>