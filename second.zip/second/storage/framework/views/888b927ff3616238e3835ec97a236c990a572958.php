<?php $__env->startSection('text'); ?>
<h1 align="center">Login</h1>


<div id="login">
<form onsubmit="return(validate())">
<fieldset>
	Name   :<input type="text"><br>
		number :<input type="text"><br>
		email  :<input type="text"><br>
		gender :
		<input type="radio" name="gender" value="male" checked> Male
		<input type="radio" name="gender" value="male"> FeMale<br>
userid<input id="1" type="text"  placeholder="Enter your Username here" ></br>
pswrd<input id="2" type="password"  placeholder="Enter your Password here" ></br>
<input type="button"  value="Login"  onclick="validate()">
</form>
</fieldset>
</div>
<script>
function validate()
{
if(document.getElementById("1").value=="")
{
alert("Please enter the Username");
document.getElementById("1").focus();
return false;
}
if(document.getElementById("2").value=="")
{
alert("Please enter the Password");
document.getElementById("2").focus();
return false;
}
if(userid ==  pswrd) 
				{
                    alert("u n p matches");
                }
                else {
                    alert("Error Password or Username");
                }
            }

</script>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>