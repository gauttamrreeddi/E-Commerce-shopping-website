<?php $__env->startSection('text'); ?>
<h1 align="center"></h1>
<title>customer care</title>
<style>
#login
{
margin-top: 20px;
margin-left:900px;
width: 450px;
text-align: center;
}
h2
{
font-size: 2em;
color:Black;
}
h2, p
{
margin-bottom: 10px;
}
strong
{
font-weight: bold;
}
#main_para
{
color: #f4f4f4;
display: block;
font-size: 60px;
font-family: 'Open Sans', Arial, Helvetica, sans-serif;
height: 50px;
line-height: 20px;
margin: 170px 20px;
width: 750px;
float: left;
}
#navigationbar
{
margin-top: 24px;
margin-left:-800px;
float: left;
}
ul
{
list-style-type: none;
margin= 0;
padding= 0;
overflow: hidden;
background-color:Black;
}
li
{
float: left;
}
li a
{
display: block;
color: Black;
text-align: center;
padding: 10px 20px;
text-decoration: none;
}
li a:hover
{
background-color: darkgreen;
}
}
</style>
</br></br>
<div id="login">
<fieldset>
	  
	

<legend><h2><strong>Details..!</strong></h2></legend>
<p><h1>Name : Gowtham</h1></p>
<p><h1>emailid : gau@gmail.com</h1></p>
<p><h1>Contact No. : 9855128685</h1></p>
<p><h3>Address : Lovely Professional University</h3></p>
<p><h3>City : Jalandhar</h3></p>
</fieldset>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>