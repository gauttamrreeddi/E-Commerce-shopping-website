

<!DOCTYPE html>
<html>
<head>
<title>customer care</title>
<style>
#login
{
margin-top: 20px;
margin-left:900px;
width: 450px;
text-align: center;
}
h2
{
font-size: 2em;
color:Black;
}
h2, p
{
margin-bottom: 10px;
}
strong
{
font-weight: bold;
}
#main_para
{
color: #f4f4f4;
display: block;
font-size: 60px;
font-family: 'Open Sans', Arial, Helvetica, sans-serif;
height: 50px;
line-height: 20px;
margin: 170px 20px;
width: 750px;
float: left;
}
#navigationbar
{
margin-top: 24px;
margin-left:-800px;
float: left;
}
ul
{
list-style-type: none;
margin= 0;
padding= 0;
overflow: hidden;
background-color:Black;
}
li
{
float: left;
}
li a
{
display: block;
color: Black;
text-align: center;
padding: 10px 20px;
text-decoration: none;
}
li a:hover
{
background-color: darkgreen;
}
}
</style>
</head>
<body background="img/ShoppingWomencopy.jpg" length: 150px, width: 150px>

<div id="main_para">
</br>
</div></center></ul>
</div></center></ul>
<div id="navigationbar">
<ul>

<li><a href="home" style="color:white">Home</a></li>
<li><a href="/product/create"  style="color:white">Register</a></li>
<li><a href="mobile" style="color:white">Mobiles</a></li>
<li><a href="mens" style="color:white">Men </a></li>
<li><a href="women"  style="color:white">Women</a></li>
<li><a href="product"  style="color:white">Update Details</a></li>
<li><a href="contact" style="color:white">Customer Care</a></li>
<li><a href="login" style="color:white">LogOut</a></li>


</br></br>
</ul>
<?php echo $__env->yieldContent('text'); ?>
</br></br>
<div id="login">

</div>
</body>
</html>